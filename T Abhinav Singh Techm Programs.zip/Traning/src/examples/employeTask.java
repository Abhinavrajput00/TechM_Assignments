package examples;


	public class employeTask {
	int empid;
	String empName;
	double salary;
	int exp;
	
	void setEmployeeDetails(int empid,String empName,double salary,int exp){
		this.empid=empid;
		this.empName=empName;
		this.salary=salary;
		this.exp=exp;
	}
	void getEmployeeDetails()
	{
		System.out.println("Employe Name = "+empName+"\n Employee Salary = "+salary+"./n And the employe has an experience of "+exp);
}
	void getLoanEligibility() {
		if(exp>5) {
			if(salary <= 600000) {
				System.out.println("Employee is Elligible for 2lakhs Loan");
			}
			else if(salary <= 1000000){
				System.out.println("Employee is Elligible for 5lakhs Loan");
			}
			else if(salary <=1500000) {
				System.out.println("Employee is Elligible for 7lakhs Loan");
			}
		}
		else
		{
			System.out.println("Employee is Not Elligible for Loan");
		}
	}



	public static void main(String args[])
	{
		employeTask emp1=new employeTask();
		emp1.setEmployeeDetails(1,"Ashish",1000000,6);
		emp1.getEmployeeDetails();
		emp1.getLoanEligibility();
	}

}