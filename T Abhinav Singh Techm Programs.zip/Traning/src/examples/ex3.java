package examples;
import static java.lang.Integer.*;

public class ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1,num2,res;
		
		num1=parseInt(args[0]);
		num2=parseInt(args[1]);
		res=num1+num2;
		System.out.print(res);

	}

}
