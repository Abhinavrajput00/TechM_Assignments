package examples;
import static java.lang.Math.*;
import java.util.Scanner;
public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		double radius=sc.nextDouble();
		double area=PI*pow(radius,2);
		System.out.print(area);
		
		
	}

}
