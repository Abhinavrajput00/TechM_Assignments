package examples;
import java.util.Arrays;
import java.util.Scanner;
public class task2 {
	public static void main(String args[])
	{
		System.out.print("Enter the No of Students");
		Scanner sc=new Scanner(System.in);
		int no=sc.nextInt();
		
		String [] names=new String[no];
		for(int i=0;i<no;i++)
		{
			System.out.println("Enter Students names");
			names[i]=sc.next();	
		}
		
		int marks[][]= new int[no][3];
		
		for(int i=0;i<no;i++) {
			for(int j=0;j<3;j++) {
				System.out.println("Enter marks of"+names[i]);
				marks[i][j]=sc.nextInt();
				
			}
		}
		
		int avg[]=new int [no];
		for(int i=0;i<no;i++) {
			int sum=0;
			for(int j=0;j<3;j++) {
				sum+=marks[i][j];
			}
			avg[i]=sum/3;
		}
		
		for(int i=0;i<no;i++) {
			for(int j=0;j<3;j++) {
				if(avg[i]>avg[j]) {
					int x=avg[i];
					avg[i]=avg[j];
					avg[j]=x;
				}
			}
		}
		
		System.out.print(Arrays.toString(avg));
		
		
	}

}
