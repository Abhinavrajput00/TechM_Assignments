package examples;
import java.lang.System;
import java.util.Arrays;
public class task3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr1[]= {1,2,3,4,5};
		int arr2[]= {1,2,3,4,5};
		int arr3[][]= {{1,2,3},{4,5,6}};
		int arr4[][]= {{1,2,3},{4,5,6}};
		if(Arrays.equals(arr1,arr2)) {
			System.out.println(true);
		}
		if(Arrays.deepEquals(arr3, arr4)){
			System.out.println(true);
		}
	}

}
