package com.example.exception;

public class TicketException extends Exception{
	public TicketException(String message){
		super(message);
	}
}
