package com.example.Spring_Web_Flux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebFluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
