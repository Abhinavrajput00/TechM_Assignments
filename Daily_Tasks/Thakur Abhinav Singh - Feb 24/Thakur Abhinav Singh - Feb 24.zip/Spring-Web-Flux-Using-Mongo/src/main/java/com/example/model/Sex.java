package com.example.model;

public enum Sex {
	Man,Woman
}
