package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebFluxUsingMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebFluxUsingMongoApplication.class, args);
	}

}
