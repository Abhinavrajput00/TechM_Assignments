package org.bhanu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPropsApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootPropsApplication.class, args);
	}

}
