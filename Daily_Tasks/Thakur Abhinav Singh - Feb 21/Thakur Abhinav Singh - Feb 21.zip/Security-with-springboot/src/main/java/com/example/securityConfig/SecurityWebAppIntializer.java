package com.example.securityConfig;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityWebAppIntializer extends AbstractSecurityWebApplicationInitializer {
}
