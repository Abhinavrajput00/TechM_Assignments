let Name: string = "John Doe";
let age: number = 30;

console.log(`Name: ${Name}`);
console.log(`Age: ${age}`);