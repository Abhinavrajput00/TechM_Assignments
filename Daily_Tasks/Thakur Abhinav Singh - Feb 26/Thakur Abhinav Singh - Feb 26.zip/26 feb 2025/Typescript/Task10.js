var isNull = null;
var isUndefined = undefined;
console.log(isNull);
console.log(isUndefined);
