let isNull: null = null;
let isUndefined: undefined = undefined;
console.log(isNull);
console.log(isUndefined);